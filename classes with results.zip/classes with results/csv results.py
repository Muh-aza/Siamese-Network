import csv
import json
import io
import os

f = open("results google.json", "r")
g_predictions = json.load(f)
f.close()

f = open("results mmocr.json", "r")
mmocr_predictions = json.load(f)
f.close()

results = g_predictions + mmocr_predictions

rows = [
    [
        "model",
        "word acc",
        "word acc ignore case",
        "word acc ignore case symbol",
        "char recall",
        "char precision",
        "1-N.E.D",
    ]
]

for r in results:
    rows.append(
        [
            r["model"],
            r["word metrics"]["word_acc"],
            r["word metrics"]["word_acc_ignore_case"],
            r["word metrics"]["word_acc_ignore_case_symbol"],
            r["char metrics"]["char_recall"],
            r["char metrics"]["char_precision"],
            r["one minus NED metric"]["1-N.E.D"],
        ]
    )

f = open("results.csv", "w", newline="")
writer = csv.writer(f)
writer.writerows(rows)
f.close()
