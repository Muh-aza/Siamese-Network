import json
import io
import os

files = {"paths": [], "gt": []}

classes = os.listdir('classes/')

for c in classes:
    gt = c
    images = os.listdir('classes/' + c)
    for i in images:
        path = f"classes/{c}/{i}"
        files['paths'].append(path)
        files['gt'].append(gt)

f = open("file list.json", "w")
json.dump(files, f)
f.close()