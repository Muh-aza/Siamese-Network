from mmocr.apis import TextRecInferencer
import json
import io
import os

f = open("file list.json", "r")
files = json.load(f)
f.close()

# reference https://mmocr.readthedocs.io/en/dev-1.x/modelzoo.html#text-recognition when updating list
models = ['ABINet_Vision', 'ABINet', 'ASTER', 'CRNN', 'MASTER', 'nrtr_modality-transform_6e_st_mj', 'NRTR', 'NRTR_1/16-1/8', 'svtr-small', 'svtr-base', 'RobustScanner', 'SAR', 'sar_resnet31_sequential-decoder_5e_st-sub_mj-sub_sa_real', 'SATRN', 'SATRN_sm']
results = []

for m in models:
    print("generating predictions for " + m)
    result = files.copy()
    result['model'] = m
    infer = TextRecInferencer(model=m)
    result['predictions'] = infer(result['paths'])
    results.append(result)

f = open("mmocr predictions.json", "w")
json.dump(results, f)
f.close()