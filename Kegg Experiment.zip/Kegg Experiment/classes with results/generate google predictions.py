import json
import io
import os

key = "google api key"
quota_project_id = "google project id"

def detect_text(path):
    """Detects text in the file."""
    from google.cloud import vision

    client = vision.ImageAnnotatorClient(
        client_options={"api_key": key, "quota_project_id": quota_project_id}
    )

    with open(path, "rb") as image_file:
        content = image_file.read()

    image = vision.Image(content=content)

    response = client.text_detection(image=image)
    texts = response.text_annotations
    
    if len(texts) > 0:
        return texts[0].description
    
    return ''


f = open("file list.json", "r")
files = json.load(f)
f.close()

results = []

print("generating predictions for google ocr")
result = files.copy()
result['model'] = "google ocr"
predictions = []
for p in result['paths']:
    predict = detect_text(p)
    print(predict)
    predictions.append(predict)

result['predictions'] = predictions
results.append(result)

f = open("google predictions.json", "w")
json.dump(results, f)
f.close()