from mmocr.evaluation.metrics import WordMetric, CharMetric, OneMinusNEDMetric
import json
import io
import os

f = open("google predictions.json", "r")
predictions = json.load(f)
f.close()

results = []

for p in predictions:
    print("generating for model " +  p['model'])
    result = {}
    result['model'] = p['model']
    converted_predictions = []
    for i in range(len(p['gt'])):
        # this format may change. reference mmocr source code for evaluators for versions after 1.0
        prediction = { 'pred_text': {'item': p['predictions'][i]}, 'gt_text': {'item': p['gt'][i]} }
        converted_predictions.append(prediction)

    wordMetric = WordMetric(['exact', 'ignore_case', 'ignore_case_symbol'])
    wordMetric.process(None, converted_predictions)
    wordMetrics = wordMetric.compute_metrics(wordMetric.results)
    result['word metrics'] = wordMetrics
        
    charMetric = CharMetric()
    charMetric.process(None, converted_predictions)
    charMetrics = charMetric.compute_metrics(charMetric.results)
    result['char metrics'] = charMetrics
        
    oneMinusNEDMetric = OneMinusNEDMetric()
    oneMinusNEDMetric.process(None, converted_predictions)
    oneMinusNEDMetrics = oneMinusNEDMetric.compute_metrics(oneMinusNEDMetric.results)
    result['one minus NED metric'] = oneMinusNEDMetrics

    results.append(result)


f = open("results google.json", "w")
json.dump(results, f)
f.close()